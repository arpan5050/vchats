# XYZ Meet

- React
- WebRTC

## Installation
<pre>
  <code>
    /* Install */
    npm install
    
    /* Run */
    npm start
  </code>
</pre>