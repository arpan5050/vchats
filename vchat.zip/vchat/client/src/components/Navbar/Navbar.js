import React from 'react'
import moment from 'moment'
const Navbar = () => {

    const getTimeandDate = () =>{
        return moment().format("ddd, MMM Do, h:mm a");
    }
    return (
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div className="container navbar-container">
       <div>
       <a class="navbar-brand" href="#">Shivila Interview</a>
       </div>
  
        
            <span class="navbar-text">
            {getTimeandDate()}
            </span>
        
        </div>
    </nav>
    )
}

export default Navbar
